﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AttributesLib;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace AttributesConsole
{

    
    class Program
    {
        delegate string AddAndStringify(int x1, int y1);
        static void Main(string[] args)
        {
            AddAndStringify y = delegate(int x1, int y1)
            {
                return (x1 + y1).ToString();
            };

            y = (a, b) => (a + b).ToString();

            //AutomobileWithTwoWheels motorBike = new AutomobileWithTwoWheels();

            DebuggerStepThrough example = new DebuggerStepThrough();

            var myString = example.ReturnHelloWorld();

            //Serialization
            Person p = new Person() { FirstName = "Narendra", LastName = "Modiji", Age = 60 };
            serialize(p, "c:\\users\\131377\\desktop\\personfile.data");


            MyValidator.Validate(p);

            Console.WriteLine(myString);
            Console.ReadLine();

        }


        static void serialize(Person p, string filePath) {
            BinaryFormatter serializer = new BinaryFormatter();
            FileStream fs = File.Create(filePath);
            try
            {
                serializer.Serialize(fs, p);
            }
            finally {
                fs.Dispose();
            }

        }
    }
}
