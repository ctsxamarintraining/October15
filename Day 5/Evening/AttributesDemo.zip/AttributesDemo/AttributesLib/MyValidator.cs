﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AttributesLib
{
    public class MyValidator
    {
        public static void Validate(object anyObj){
            Type currentType = anyObj.GetType();
            int vowelCount = 0;
            VowelCountValidationAttribute attribute = null;
            foreach (PropertyInfo pInfo in currentType.GetProperties()) {
                attribute = pInfo.GetCustomAttribute<VowelCountValidationAttribute>();
                if (attribute == null){
                    continue;
                }

                if(pInfo.PropertyType != typeof(string)){
                    throw new Exception("Invalid data type!! This Attribute can be used only on string");
                }
                var value = pInfo.GetValue(anyObj).ToString().ToLower();
                var vowels = new char[] {'a','e','i','o','u'};
                vowelCount = 0;

                foreach (char c in value) {
                    if (vowels.Contains(c)) {
                        vowelCount++;
                    }
                }

                if (attribute != null && vowelCount > attribute.MaxCount)
                    throw new Exception("Vowel count check failed!!");
               
            }

           
        }
    }
}
