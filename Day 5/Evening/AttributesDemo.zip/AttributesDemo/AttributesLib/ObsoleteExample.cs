﻿using System;
namespace AttributesLib
{
    [Obsolete("Hey Developer. This type is obsolete. Please use the new MotorBike instead", true)]
    public class AutomobileWithTwoWheels
    {

    }

    public class MotorBike
    {

    }

}