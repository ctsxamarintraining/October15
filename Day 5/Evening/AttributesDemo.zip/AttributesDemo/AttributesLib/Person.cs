﻿using System;

namespace AttributesLib
{    
    [Serializable]
    public class Person
    {
        [VowelCountValidation(5)]
        public string FirstName { get; set; }

        [VowelCountValidation(2)]
        public string LastName { get; set; }

        //[VowelCountValidation(2)]
        public int Age { get; set; }
    }    
}
