﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesLib
{
    [AttributeUsage (AttributeTargets.Property)]
    public class VowelCountValidationAttribute: Attribute
    {
        public int MaxCount { get; set; }
        public VowelCountValidationAttribute(int maxCount) {
            this.MaxCount = maxCount;
        }
    }
}
