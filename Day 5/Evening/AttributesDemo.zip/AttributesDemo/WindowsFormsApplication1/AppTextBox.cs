﻿using System.ComponentModel;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public class AppTextBox : TextBox
    {

        [Browsable(true)]
        [DisplayName("Main Textbox")]
        public bool IsMain { get; set; }
    }
}
