﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameTextbox = new System.Windows.Forms.TextBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.appTextBox2 = new WindowsFormsApplication1.AppTextBox();
            this.appTextBox1 = new WindowsFormsApplication1.AppTextBox();
            this.SuspendLayout();
            // 
            // nameTextbox
            // 
            this.nameTextbox.Location = new System.Drawing.Point(12, 12);
            this.nameTextbox.Name = "nameTextbox";
            this.nameTextbox.Size = new System.Drawing.Size(146, 20);
            this.nameTextbox.TabIndex = 0;
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(177, 9);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 1;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // appTextBox2
            // 
            this.appTextBox2.IsMain = false;
            this.appTextBox2.Location = new System.Drawing.Point(164, 73);
            this.appTextBox2.Name = "appTextBox2";
            this.appTextBox2.Size = new System.Drawing.Size(100, 20);
            this.appTextBox2.TabIndex = 3;
            // 
            // appTextBox1
            // 
            this.appTextBox1.IsMain = false;
            this.appTextBox1.Location = new System.Drawing.Point(26, 73);
            this.appTextBox1.Name = "appTextBox1";
            this.appTextBox1.Size = new System.Drawing.Size(100, 20);
            this.appTextBox1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 276);
            this.Controls.Add(this.appTextBox2);
            this.Controls.Add(this.appTextBox1);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.nameTextbox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTextbox;
        private System.Windows.Forms.Button okBtn;
        private AppTextBox appTextBox1;
        private AppTextBox appTextBox2;
    }
}

